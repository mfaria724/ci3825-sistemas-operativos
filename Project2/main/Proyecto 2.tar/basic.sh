grep 1 pruebaGrep.txt
grep -iv "hola" < archivoPrueba.txt > poema.txt
ls|grep rep

ls -iGgh pruebaGrep.txt
ls -ihgGR > folderContents.txt
ls .. -R > neighborContents.txt
ls -l ../. > parentContents.txt
ls -@

chmod pruebaGrep.txt +x -w
chmod  +xw archivoPrueba.txt
chmod poema.txt -r

chmod | ls
chmod | grep foo
grep b pruebaGrep.txt | ls
ls|grep .|grep txt
ls .. -R|grep 2019|grep txt>textos2019.txt
grep . archivoPrueba.txt|chmod +w